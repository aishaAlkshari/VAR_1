/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainapp;

import mainapp.ReportDatabase;
import mainapp.ReportGeneratorLayer;

/**
 *
 * @author aisha_alkshari
 */
public class ReportLayer {
        private final ReportDatabase db;
    private final ReportGeneratorLayer reportGenerator;

    public ReportLayer(ReportDatabase db, ReportGeneratorLayer generator) {
        this.db = db;
        this.reportGenerator = generator;
    }

    public void requestReportGeneration(int inspectionId) {
        System.out.println("AppLayer: RequestReportGeneration");

        // Step 1: fetch inspection data
        db.fetchInspectionData(inspectionId);

        // Step 2: generate PDF
        reportGenerator.generatePDF(inspectionId);

        // Step 3: Save report
        db.saveReportRecord(inspectionId);

        // Step 4: respond back
        System.out.println("AppLayer: ReportSubmittedSuccessfully");
    }
}
