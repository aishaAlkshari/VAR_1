/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainapp;

/**
 *
 * @author aisha_alkshari
 */
public class ReportInspectorApp {
    private final ReportLayer appLayer;

    public ReportInspectorApp(ReportLayer appLayer) {
        this.appLayer = appLayer;
    }

    

    public void submitInspection(int inspectionId) {
        System.out.println("Inspector: submitting inspection " + inspectionId);
        appLayer.requestReportGeneration(inspectionId);
    }
    
}