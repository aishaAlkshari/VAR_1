/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainapp;

/**
 *
 * @author aisha_alkshari
 */
public class InspectionReport {

    public static void main(String[] args) {
        ReportDatabase db = new ReportDatabase();
        ReportGeneratorLayer generator = new ReportGeneratorLayer();
        ReportLayer app = new ReportLayer(db, generator);
        ReportInspectorApp inspector = new ReportInspectorApp(app);

        inspector.submitInspection(101); 
    }
    
}