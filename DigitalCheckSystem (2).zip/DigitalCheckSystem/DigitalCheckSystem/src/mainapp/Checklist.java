
package mainapp;

import java.util.ArrayList;
/**
 *
 * @author noma
 */
public class Checklist {
    
    private ArrayList<ChecklistItem> items = new ArrayList<>();

    public void addItem(String question){
        items.add(new ChecklistItem(question));
    }

    public void showItems(){
        System.out.println("\nChecklist Items:");
        for (ChecklistItem item : items) {
            System.out.println("- " + item.question);
        }
    }  
}
