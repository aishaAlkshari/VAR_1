/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainapp;

/**
 *
 * @author aisha_alkshari
 */
public class UploadPhotographicEvidence {

    public static void main(String[] args) {
        PhotoLayer appLayer = new PhotoLayer();
        PhotoInspectorApp inspector = new PhotoInspectorApp(appLayer);
        inspector.selectPhoto();
    }
}