/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainapp;

import mainapp.PhotoDatabase;
import mainapp.FillStorage;

/**
 *
 * @author aisha_alkshari
 */

public class PhotoLayer {
    FillStorage storage = new FillStorage();
    PhotoDatabase db = new PhotoDatabase();
    
    public boolean uploadPhoto(String name){
        String link = storage.storeFile(name);
        return db.recordSavePhoto(link);
        
    }

    
}